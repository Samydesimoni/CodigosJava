package br.com.generation.variaveis;

public class Variavel02 {
	
	//OperadoresAritmeticos
	public static void main(String[] args) {
		
		int x = 5;
	    int y = 10;
	    int resultado; 
	    
	    resultado = x + y;
	    System.out.println("soma: " + resultado);
				
	    

	}

}
