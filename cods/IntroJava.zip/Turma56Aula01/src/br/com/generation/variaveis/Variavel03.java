package br.com.generation.variaveis;

public class Variavel03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int var1 = 10;
		double var2 = 10.0;
		
		System.out.println("Valor Original da 1� variavel: " + var1);
		System.out.println("Valor Original da 2� variavel: " + var2);
		System.out.println();
		
		var1 = var1 / 4;
		var2 = var2 / 4;
		
		System.out.println("Valor Original da 1� variavel: " + var1);
		System.out.println("Valor Original da 2� variavel: " + var2);
		

	}

}
