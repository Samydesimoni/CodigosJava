package br.com.generation.variaveis;

public class Variavel01 {

	public static void main(String[] args) {
		
		//int numero1; 
		//int *numero;
		
		//int _numero;
		//int $numero;
		
		int idade = 10;
		double preco = 10.0;
		char sexo = 'F';
		boolean temFilhos = true;
		String login = "nome@gmail.com";
		
		byte a = -128;
		
		
		Double valor = 25.68;
		System.out.println(idade);
		System.out.println(preco);
		System.out.println(sexo);
		System.out.println(temFilhos);
		System.out.println(login);
		
	
		
        
	}

}
