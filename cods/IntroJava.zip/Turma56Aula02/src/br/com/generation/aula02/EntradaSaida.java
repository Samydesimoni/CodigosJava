package br.com.generation.aula02;

import java.util.Scanner;

public class EntradaSaida {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in); //entrada de dados do usuario
		
		int a, b, soma;
		System.out.println("Escreva o valor de A: ");
		a = leia.nextInt(); // valor que tem ser guardado
		
		System.out.println("Escreva o valor de B: ");
		b = leia.nextInt();
		
		soma = a + b;
		System.out.println("Resultado da soma: " + soma);
		
		leia.close();

	}

}
