package br.com.generation.aula02;

import java.util.Scanner;

public class GalaoLitro {

	public static void main(String[] args) {
		
		double litros;
		int galoes;
		
		Scanner leia = new Scanner(System.in);
		
		System.out.println("Digite a quantidade de gal�es: ");
		galoes = leia.nextInt();
	
		
		litros = galoes * 3.600;
		
		System.out.println(galoes + " gal�es s�o: " + litros + " litros.");

	}

}
