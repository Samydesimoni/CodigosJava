package br.com.generation.operadoresdeatribuicao;

public class OperadorAtribuicao {

	public static void main(String[] args) {
		
		int x = 10;
		System.out.println(x);
		
		x += 25;
		
		System.out.println(x);
		
		x /= 2; // x = x / 2
		
		System.out.println(x);

		x %= 2;
		
		System.out.println(x);
	}

}
