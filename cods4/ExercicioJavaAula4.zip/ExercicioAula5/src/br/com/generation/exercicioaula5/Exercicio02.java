package br.com.generation.exercicioaula5;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		int [] res = new int[10];
		double media = 0.0, soma = 0.0;
		int maiorOcor = 0, maior = 0;
		
		for(int i = 0; i <= 9; i++) {
			System.out.println("Insira as pontua��es: ");
			res[i] = leia.nextInt();	
		}
		for(int i = 0; i < 9; i++) {
			soma += res[i];
			
			if(res[i] == maior) {
				maiorOcor++;
			}
			if(res[i] > maior) {
				maior = res[i];
				
						
			}
		}
		
		media = soma / 9;
		
		System.out.println("O maior lance foi: " + maior + " ele apareceu " + maiorOcor + "\n");
		System.out.println("A m�dia foi de: " + media);
		

	}

}
