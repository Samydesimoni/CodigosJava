package br.com.generation.exercicioaula5;

import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		
		int [][] matriz = new int [3][3];
		
		int soma = 0, somaDiagonal, maior = 0, menor = 1000;
		
		System.out.println("Insira os valores da matriz: \n");
		
		for(int l = 0; l <= 2; l++) {
			for(int c = 0; c <= 2; c++) {
				matriz[l][c] = leia.nextInt();
				
				soma += matriz[l][c];
				if(matriz[l][c] > maior) {
					maior = matriz[l][c];
				}
				if(matriz[l][c] < menor) {
					menor = matriz[l][c];
				}
			}
		}
		somaDiagonal = matriz[0][0] + matriz[1][1] + matriz[2][2];
		System.out.println("A soma total da matriz �: " +soma);
		System.out.println("\nA soma da diagonal �: "+somaDiagonal);
		System.out.println("\nO maior valor da matriz �: "+maior);
		System.out.println("\nO menor valor da matriz �: "+menor);
		
			

		          

	}

}
