package br.com.generation.exercicioaula5;

public class Exercicio03 {

	public static void main(String[] args) {
		
		int [][] n1 = new int [4][6];
		int [][] n2 = new int [6][4];
		int [][] m1 = new int [0][0];
		int [][] m2 = new int [0][0];
		
		for(int l = 0; l <= 1; l++) {
			m1[l]= n1[l] + n2[l];
			m2[l] = n1[l] - n2[l];	
		}
		for(int l = 0; l <= 1; l++) {
			System.out.println("\nMatriz m1[" + l + "]: " +m1[l]);
			
			
		}
		System.out.println("\n");
		for(int l = 0; l <= 1; l++) {
			System.out.println("\nMatriz m2[" + l + "]: " +m2[l]);
		}
		
		

	}

}
