package br.com.generation.exercicioaula5;

import java.util.Scanner;

public class Exercicio01 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		int [] pont = new int[5];
		int maiorValor = 0;
		
		for(int i = 0; i <= 4; i++) {
			System.out.println("Insira a pontua��o: ");
			pont[i] = leia.nextInt();	
		}
		
		for(int i = 0; i <= 4; i++) {
			System.out.print(pont[i] + " | ");
			if(pont[i] > maiorValor) {
				maiorValor = pont[i];
				
			}
		}
		
		System.out.println("\nA maior pontua��o �: " +maiorValor);
		
		
		
		

	}

}
