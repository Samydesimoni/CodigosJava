package br.com.generation.exerciciosaualatres;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		int num1, num2, num3;
		
		System.out.println("Insira o primeiro n�mero: ");
		num1 = entrada.nextInt();
		
		System.out.println("Insira o segundo n�mero: ");
		num2 = entrada.nextInt();
		
		System.out.println("Insira o terceiro n�mero: ");
		num3 = entrada.nextInt();
		
		if(num1 < num2 && num1 < num3 && num2 < num3) {
			System.out.println(num1 + "-" + num2 + "-" + num3);
			if(num2 < num1 && num2 < num3 && num1 > num3) {
				System.out.println(num2 + "-" +num3+ "-" + num1);
				if(num3 < num1 && num3 < num2 && num1 < num2);
				System.out.println(num3 + "-" +num1+ "-" +num2);
				
			}
		}
		
		
		

	}

}
