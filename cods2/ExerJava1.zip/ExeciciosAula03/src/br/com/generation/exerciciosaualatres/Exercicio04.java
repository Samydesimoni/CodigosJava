package br.com.generation.exerciciosaualatres;

import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		int num, soma, multi1, multi2;
		
		System.out.println("Insira um n�mero: ");
		num = entrada.nextInt();
		
		if(num % 2 == 0) {
			soma = num / 2;
			multi1 = soma * soma;		
			System.out.println("Par" + "\n" + "E sua raiz quadrada �: " +soma);
			
		}else if(num % 2 != 0);
		multi2 = num * num;
		System.out.println("�mpar" + "\n" + "E o resultado da exponencia��o �: "+multi2);
		
			
				
			}
		
		
	}


