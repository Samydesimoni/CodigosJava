package br.com.generation.exerciciosaualatres;

import java.util.Scanner;

public class Execicio01 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		int a, b, c;
		
		System.out.println("Insira o primeiro n�mero: ");
		a = entrada.nextInt();
		
		System.out.println("Insira o segundo n�mero: ");
		b = entrada.nextInt();
		
		System.out.println("Insira o terceiro n�mero: ");
		c = entrada.nextInt();
		
		if(a > b && a > c) { 
			System.out.println(a + " � o maior n�mero.");
		}
		if(b > a && b > c) {
			System.out.println(b + " � o maior n�mero.");
		}
		if(c > a && c > b) {
			System.out.println(c + " � o maior n�mero.");
		}
		
		

	}

}
