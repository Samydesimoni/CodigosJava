package br.com.generation.exerciciosJava;

import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		int num, par = 0, impar = 0;
		
		for(int i = 1; i <= 10; i++) {
			System.out.println("Digite o " + i + "� n�mero");
			num = leia.nextInt();
			
			if(num % 2 == 0) {
			par++;
			
			}
		if(num % 2 != 0) {
		impar++;
		
	   

		}
		
		}
		
		System.out.println("Os n�meros pares s�o: " + par);
		System.out.println("Os n�meros �mpares s�o: " + impar);
		
	}
}	 
		
		
