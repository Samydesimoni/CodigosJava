package br.com.generation.exerciciosJava;

import java.util.Scanner;

public class Exercico03 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		int num = 1, contador1 = 0, contador2 = 0;
		
		while(num <= 98) {
			System.out.println("Digite as respectivas idades e digite 99 para sair: ");
			num = leia.nextInt();
			
			if(num <= 21) {
				contador1++;
			}
				
				if(num >= 50 && num <= 98) {
					contador2++;
					
				}
			
		}
		
		System.out.println("Total de pessoas com menos de 21 anos: " + contador1);
		System.out.println("Total de pessoas com mais de 50 anos: " + contador2);
	}

}
