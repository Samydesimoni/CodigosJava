package br.com.generation.exerciciosJava;

import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
	int idade, sexo, personalidade;
	int pssCal = 0, mulNerv = 0, homAgress = 0, outCalm = 0, nervMaior40 = 0, calmMenor18 = 0, contador = 0;
	
	while(contador <= 4) {
		
			System.out.println("Digite dua idade: ");
			idade = leia.nextInt();
			
			
			do { 
				System.out.println("Escolha o n�mero correspondente ao seu g�nero: (1) Feminino (2) Masculino (3) Outros");
				sexo = leia.nextInt();
					
			}while(sexo < 1 || sexo > 3 );
			
			
			do {
				System.out.println("Digite o n�mero correspondente ao seu comportamento: (1) Calme (2) Nervose (3) Agressive");
				personalidade = leia.nextInt();

			}while(personalidade < 1 || personalidade > 3);
			
			
			if(personalidade == 1)
				pssCal++;
			
			if(sexo == 1 && personalidade == 2)
				mulNerv++;
			
			if(sexo == 2 && personalidade == 3 )
				homAgress++;
			
			if(sexo == 3 && personalidade == 1)
				outCalm++;
			
			if(idade > 40 && personalidade == 2)
				nervMaior40++;
			
			if(idade < 18 && personalidade == 1)
				calmMenor18++;
			
			contador++;
	}
		System.out.println("O total de pessoas calmas �: "+pssCal);
		
		System.out.println("O total de mulheres nervosas �: "+mulNerv);
		
		System.out.println("O total de o homens agressivos �: "+homAgress);
		
		System.out.println("O total de outros calmes �: "+outCalm);
		
		System.out.println("O total de pessoas maiores de 40 anos nervoses �: "+nervMaior40);
		
		System.out.println("O total de pessoas menores de 18 anos calmes �: "+calmMenor18);
		
	  }
		
	

	}


