package br.com.generation.exerciciosJava;

import java.util.Scanner;

public class Exercicio06 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner (System.in);
		
		int i, soma = 0, contador = 0;
		double media;
		
		
		do {
			System.out.println("Insira um n�mero inteiro ou digite 0 para sair: ");
			i = leia.nextInt();
			
			if(i % 3 == 0) {
				soma = soma + i;
				contador++;
				
			}
			
		}while(i != 0);
		media = soma/contador;
		
		System.out.println("A m�dia dos n�meros m�ltiplos de 3 �: " +media);
			
		
           
        }
}