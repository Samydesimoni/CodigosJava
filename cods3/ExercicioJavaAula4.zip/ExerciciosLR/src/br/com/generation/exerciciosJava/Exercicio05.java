package br.com.generation.exerciciosJava;

import java.util.Scanner;

public class Exercicio05 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		
		int num, soma = 0;
		
		do {
			System.out.println("Digite um n�mero ou zero para sair: ");
			num = leia.nextInt();
		    soma += num;
			
		}while(num !=  0);
		
		System.out.println("O resultado da soma �: " + soma);
			
		}

	}

       
